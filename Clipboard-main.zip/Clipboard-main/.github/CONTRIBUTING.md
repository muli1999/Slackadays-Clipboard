# Thanks for contributing to Clipboard! 👋

We are always accepting new contributions, whether it's code, documentation, or something else. 

- Please make sure that your contributions are properly attributed so that we can keep track of all the authors involved.

- Keep your contributions as modularized as possible. That way, it's easier to make decisions on each individual contribution.
