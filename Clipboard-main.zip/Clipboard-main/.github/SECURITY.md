# Security Policy

## Supported Versions

| Version | Supported          |
| ------- | ------------------ |
| Latest commit/release   | :white_check_mark: |
| Not latest commit/release   | :x:                |

## Reporting a Vulnerability

If you find a vulnerability that is not the result of user error, email the authors or report it in the GitHub Security section.
