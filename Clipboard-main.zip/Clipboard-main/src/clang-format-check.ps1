clang-format --Werror -i --verbose --dry-run (Get-ChildItem -Recurse -Include *.cpp,*.hpp)
