clang-format --Werror -i --verbose (Get-ChildItem -Recurse -Include *.cpp,*.hpp)
