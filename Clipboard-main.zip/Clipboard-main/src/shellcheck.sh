#!/bin/sh

shellcheck -e SC1091 ./*.sh tests/*.sh